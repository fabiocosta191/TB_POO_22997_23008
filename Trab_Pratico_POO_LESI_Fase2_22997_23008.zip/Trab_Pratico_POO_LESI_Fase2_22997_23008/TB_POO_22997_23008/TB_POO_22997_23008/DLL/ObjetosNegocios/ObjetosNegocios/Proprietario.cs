﻿/*
 *  Class Proprietario
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using Interfaces;
using System;

namespace ObjetosNegocios
{
    [Serializable]
    public class Proprietario : IProprietario
    {
        #region ATRIBUTOS
        private string nomeProp;
        private string iban;
        private int contribuinteProp;
        private int contatoProp;
        #endregion

        #region COMPORTAMENTO
        #region CONSTRUTORES
        public Proprietario() 
        {

        }
        public Proprietario (string nomeProp, string iban, int contribuinteProp, int contactoProp)
        {
            this.nomeProp = nomeProp;
            this.iban = iban;
            this.contribuinteProp = contribuinteProp;
            this.contatoProp = contactoProp;
        }
        #endregion
        #region PROPRIEDADES
        public string NomeProp
        {
            get { return nomeProp; }
            set { nomeProp = value; }
        }
        public string Iban
        {
            get { return iban; }
            set { iban = value; }
        }
        public int ContribuinteProp
        {
            get { return contribuinteProp; }
            set { contribuinteProp = value;}
        }
        public int ContactoProp
        {
            get { return contatoProp; }
            set { contatoProp = value; }
        }
        #endregion

        #region OUTROS METODOS
        /// <summary>
        /// Vai compararar a propriedade contribuinteProp de dois objetos Proprietario para ver se são iguais.
        /// </summary>
        /// <param name="obj">Objeto</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj is Proprietario other)
            {
                return contribuinteProp == other.contribuinteProp;
            }
            return false;
        }

        /// <summary>
        /// Vai retornar o código hash especifico da instância.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return contribuinteProp.GetHashCode();
        }
        #endregion

        #endregion
    }
}
