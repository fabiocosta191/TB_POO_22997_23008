
->
	Autor: F�bio Rafael Gomes Costa || Luis Pedro Pereira Freitas
	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
	Unidade Curricular (UC): Programa��o Orientada a Objetos
	Docente: Luis Ferreira
	Contato: lufer@ipca.pt
	Curso: Licenciatura em Engenharia de Sistemas Inform�ticos
	Instituto: Escola Superior de Tecnologia do Instituto Polit�cnico do C�vado e do Ave 
<-

Este projeto � desenvolvido, no ambito da Unidade Curricular (UC) de Programa��o Orientada a Objetos (POO), 
e foca-se na an�lise de problemas reais simples e a aplica��o do Paradigma Orientado a Objetos na implementa��o
de poss�veis solu��es. Regras do trabalho em anexo "Trabalho_POO_ESI_2023_2024.pdf";





