﻿/*
 *  Class Imovel
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 01/11/2023
*/

using System;

namespace DLLImovel
{
    internal class ClasseImovel
    {
        #region Estado
        private string estadoPredial;
        private string categuria;
        private string idPredial;
        private int valorAluguer;
        private int valorPredial;
        #endregion
        #region COMPORTAMENTO

        #region CONSTROTORES

        #endregion
        #region PROPRIEDADES

        #endregion
        #endregion
    }
}
