﻿using Dados;
using ObjetosNegocios;
using System;


namespace RegrasNegocio
{
    public class RegrasImoveis
    { 
        //IMOVEL
        /// <summary>
        /// Verifica a existencia de um imovel no condominio a partir do metodo ExisteImovel e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="i">Responsável por procurar a variavel inserida pelo user na LIST Imovel</param>
        /// <returns></returns>
        public static string InsereImovel(Imovel i, Morada m)
        {

                if (GereDados.VerificaImovel(i))
                {
                    return "Imovel já existente!";
                }
                else if (GereDados.InserePropImovel(i)==false)
                {
                    return "Ficha de Cliente nao encontrada!";
                }
                else
                { 
                    GereDados.InsereImovel(i, m); 
                    return "Imovel inserido com sucesso!";
                }

        }


        /// <summary>
        /// Metodo para adicionar um proprietario ao imovel, onde verifica primeiro a existencia do imovel e depois adiciona o Proprietario
        /// </summary>
        /// <param name="i">Parametro atribuido ao imovel</param>
        /// <param name="p">Parametro atribuido ao Proprietario</param>
        /// <returns></returns>
        public static bool AdicionarPropImovel (Imovel i, Proprietario p)
        {
            if (GereDados.VerificaImovel(i))
            {
                GereDados.InsereProprietario(p);
                Console.WriteLine("Proprietário adicionado com sucesso!");
                return true;
            }
            else
            {
                return false; 
            }
        }

        public static bool PesquisarImovel(int id)
        {
            Imovel iProc = GereDados.PesquisarImovel(id);

            if (iProc != null)
            {
                Console.WriteLine("Id{0}",iProc.IdPredial);
                Console.WriteLine("Estado {0}",iProc.EstadoPredial);
                Console.WriteLine("Valor {0}",iProc.ValorAluguer);
            }
            else
            {
                Console.WriteLine("Imovel com id {0} não foi encontrado!", id);
            }
            return false; 
        }
        //CLIENTE

        /// <summary>
        /// Verifica a existencia de um Cliente no condominio a partir do metodo VerificaCliente e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="c">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static string InsereCliente(Cliente c)
        {
            if (GereDados.VerificaCliente(c))
            {
                return "Cliente já existente!";
                
            }
            else
            {
                GereDados.InsereCliente(c);
                return "Cliente inserido com sucesso!";
            }
        }

        //PROPRIETARIO
        public static string InsereProprietario (Proprietario p)
        {

            if (GereDados.VerificarProprietario(p))
            {
                return "Proprietario já existente!";
            }
            else
            {
                GereDados.InsereProprietario(p);
                return "Proprietario inserido com sucesso!";
            }

        }
    }
}
