﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosNegocios
{
    public class Contrato
    {
        #region Atributos
        private int numContrato;

        #endregion

        #region Comportamento
        #region Construtores
        public Contrato()
        {

        }
        public Contrato(int numContrato)
        {
            this.numContrato = numContrato;
            
        }
        #endregion
        #region Propriedades
        public int NumContrato
        {
            get { return numContrato; }
            set { numContrato = value; }
        }

            
        #endregion
        #endregion
    }
}
