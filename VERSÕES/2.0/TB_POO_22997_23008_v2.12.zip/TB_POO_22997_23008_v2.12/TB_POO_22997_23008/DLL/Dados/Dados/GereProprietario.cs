﻿/*
 *  Class Gere Proprietario
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 15/12/2023
 */
using ObjetosNegocios;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Dados
{
    public class GereProprietario
    {
        #region Atributos
        private static List<Proprietario> proprietario { get; set; } = new List<Proprietario>();
        #endregion

        #region Comportamento
        #region Construtores
        public GereProprietario() 
        {
        }
        #endregion
        #endregion
        #region Outros Metodos

        /// <summary>
        /// Encontra o primeiro proprietario na List cujo contribuinte seja igual ao valor fornecido e iguala esse valor ao Proprietario ( do Imovel)
        /// </summary>
        /// <param name="i">imovel</param>
        /// <returns></returns>
        public static bool InserePropImovel(Imovel i)
        {
            foreach (var p in proprietario)
            {
                if (i.Proprietario == p.ContribuinteProp)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Insere Proprietario na List
        /// </summary>
        /// <param name="p">Proprietario</param>
        /// <returns></returns>
        public static bool InsereProprietario(Proprietario p)
        {
            proprietario.Add(p);
            return true;
        }

        /// <summary>
        /// Verifica a existência de um proprietario na List
        /// </summary>
        /// <param name="p">Proprietario</param>
        /// <returns></returns>
        public static bool VerificarProprietario(Proprietario p)
        {
            return proprietario.Contains(p);
        }

        /// <summary>
        /// Encontra o primeiro proprietario na List cujo contribuinte seja igual ao valor fornecido e chama o metodo ImprimirInformacoesProprietario para imprimir as informações.
        /// </summary>
        /// <param name="contribuinteProp">Valor fornecido</param>
        /// <returns></returns>
        public static string PesquisarProprietario(int contribuinteProp)
        {

            foreach (var p in proprietario)
            {
                if (p.ContribuinteProp == contribuinteProp)
                {
                    return ImprimirInformacoesProprietario(p);  // Para de pesquisar após encontrar o primeiro imóvel com o endereço especificado
                }
            }
            return "Proprietario nao encontrado!!!";
        }

        /// <summary>
        /// Imprime as informações do proprietario
        /// </summary>
        /// <param name="p">Proprietario</param>
        /// <returns></returns>
        private static string ImprimirInformacoesProprietario(Proprietario p)
        {
            return "Nome:" + p.NomeProp + " Numero de Contribuinte:" + p.ContribuinteProp + " IBAN:" + p.Iban + " COntacto:" + p.ContactoProp;

        }

        /// <summary>
        /// Encontra o primeiro proprietario na List cujo contribuinte seja igual ao valor fornecido.
        /// </summary>
        /// <param name="contribuinteProp">Valor fornecido</param>
        /// <returns></returns>
        public static bool PesquisarProprietarioContrato(int contribuinteProp)
        {

            foreach (var p in proprietario)
            {
                if (p.ContribuinteProp == contribuinteProp)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// METODO PARA GUARDAR DADOS PROPRIETARIO 
        /// </summary>
        /// <param name="caminhoArquivo"></param>
        /// <exception cref="Exception"></exception>

        public static void GuardaDadosProprietario(string caminhoArquivo)
        {
            try
            {
                using (Stream s = File.Open(caminhoArquivo, FileMode.Create))
                {
                    BinaryFormatter b = new BinaryFormatter();
                    b.Serialize(s, proprietario);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Impossível acessar arquivo.", ex);
            }
        }

        /// <summary>
        /// Carrega dados do proprietario
        /// </summary>
        /// <param name="caminhoArquivo">Caminho do arquivo</param>
        public static void CarregaDadosProprietario(string caminhoArquivo)
        {
            if (File.Exists(caminhoArquivo) && new FileInfo(caminhoArquivo).Length > 0)
            {
                using (Stream s = File.Open(caminhoArquivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter b = new BinaryFormatter();
                    proprietario = (List<Proprietario>)b.Deserialize(s);
                }
            }
            else
            {
                proprietario = new List<Proprietario>();
            }
        }
        #endregion
    }
}
