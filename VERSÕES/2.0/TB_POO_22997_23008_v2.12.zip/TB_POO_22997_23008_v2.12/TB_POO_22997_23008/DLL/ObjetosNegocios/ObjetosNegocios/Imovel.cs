﻿/*
 *  Class Imovel
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using Interfaces;
using System;

namespace ObjetosNegocios
{
    [Serializable]
    public class Imovel : IImovel
    {
       
        #region ATRIBUTOS
        private int idPredial;
        private string estadoPredial;
        private int valorAluguer;
        private int valorPredial;
        private int proprietario;
        private string morada;


        #endregion
        #region COMPORTAMENTO

        #region CONSTRUTORES
       public Imovel()
       {

       }

        public Imovel (int idPredial, string estadoPredial, int valorAluguer, int valorPredial, string morada)
        {
            this.idPredial = idPredial;
            this.estadoPredial = estadoPredial;
            this.valorAluguer = valorAluguer;
            this.valorPredial = valorPredial;
            this.morada = morada;
        }

        #endregion
        #region PROPRIEDADES
        public int IdPredial
        {
            get { return idPredial; }
            set { idPredial = value; }
        }
        public string EstadoPredial
        {
            get { return estadoPredial; }
            set { estadoPredial = value; }
        }
        public int ValorAluguer
        {
            get { return valorAluguer; }
            set { valorAluguer = value; }
        }
        public int ValorPredial
        {
            get { return valorPredial; }
            set { valorPredial = value; }
        }
        public int Proprietario
        {
            get { return proprietario; }
            set { proprietario = value; }
        }
        public string Morada
        {
            get { return morada; }
            set { morada = value; }
        }

        #endregion

        #region OUTROS METODOS
        /// <summary>
        /// Vai compararar a propriedade idPredial de dois objetos Imovel para ver se são iguais.
        /// </summary>
        /// <param name="obj">Objeto</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj is Imovel other)
            {
                return idPredial == other.idPredial;
            }
            return false;
        }

        /// <summary>
        /// Vai retornar o código hash especifico da instância.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return idPredial.GetHashCode();
        }

        #endregion
        #endregion
    }
}
