﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegrasNegocio;
using ObjetosNegocios; 

namespace Programa_Teste
{
    public class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            while (a != 4)
            {
                Imovel i = new Imovel();
                Console.WriteLine("insere");
                string valorid = Console.ReadLine();
                int inteiroNumero = int.Parse(valorid);
                i.IdPredial = inteiroNumero;

                bool aux = RegrasImoveis.InsereImovel(i);
                Console.WriteLine("ola eu e o meu coleha {0}", aux);
                Console.ReadKey();
                /*
                Console.WriteLine("Quer inserir outro valor");
                char pp = Console.ReadLine();
                if(pp =="s")
                {a=4;}
                 */
                //i = null;
                a++;
            }
        }
    }
}
