﻿/*
 *  Class Imovel
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using Interfaces;
using System.Collections.Generic;

namespace ObjetosNegocios
{
    public class Imovel //: IImovel
    {
       
        #region ATRIBUTOS
        private int idPredial;
        private string estadoPredial;
        private int valorAluguer;
        private int valorPredial;
        private List<Morada> morada;
        private List<Proprietario> proprietario;


        #endregion
        #region COMPORTAMENTO

        #region CONSTRUTORES
        public Imovel()
        {
            morada = new List<Morada>();
            proprietario = new List<Proprietario>();
        }

        #endregion
        #region PROPRIEDADES
        public int IdPredial
        {
            get { return idPredial; }
            set { idPredial = value; }
        }
        public string EstadoPredial
        {
            get { return estadoPredial; }
            set { estadoPredial = value; }
        }
        public int ValorAluguer
        {
            get { return valorAluguer; }
            set { valorAluguer = value; }
        }
        public int ValorPredial
        {
            get { return valorPredial; }
            set { valorPredial = value; }
        }
        public List<Morada> Morada 
        { 
            get { return morada; }
            set { morada = value; }
        }

        public List<Proprietario> Proprietario
        {
            get { return proprietario; }
            set { proprietario = value; }
        }
        #endregion

        #region OUTROS METODOS
        public override bool Equals(object obj)
        {
            if (obj is Imovel other)
            {
                return idPredial == other.idPredial;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return idPredial.GetHashCode();
        }


        #endregion
        #endregion
    }
}
