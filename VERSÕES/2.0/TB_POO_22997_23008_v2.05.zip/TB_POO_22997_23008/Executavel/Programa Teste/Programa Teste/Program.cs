﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegrasNegocio;
using ObjetosNegocios; 

namespace Programa_Teste
{
    public class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            while (a != 4)
            {
                Morada m = new Morada();
                // Cria Imovel
                Imovel i = new Imovel();
                i.IdPredial = 1;

           

                string aux = RegrasImoveis.InsereImovel(i, m    );
                Console.WriteLine(" Resultado {0}", aux);
                

                //bool procImovel = RegrasImoveis.PesquisarImovel(idPesq);
                /*
                ///Cria Proprietario
                Proprietario p = new Proprietario();
                //Cria Morada
                Morada m = new Morada();
                //Cria Cliente
                Cliente c = new Cliente();
                
                // Cria novo imovel
                bool addImovel = RegrasImoveis.InsereImovel(i);
                // Adiciona Morada ao Imovel
                bool addMorada = RegrasImoveis.AdicionarMoradaImovel(i,m);
                // Adciona Prop ao Imovel
                bool addProp = RegrasImoveis.AdicionarPropImovel(i,p);

                
               
               //Console.WriteLine("insere");
              
                */





                Console.ReadKey();
                a++;
                
            }
        }
    }
}
