﻿using System;
using RegrasNegocio;
using ObjetosNegocios;


namespace pooprogram
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char repeticao = 's';

            /*
             * login
             */

            Console.Write("\n\n\t\t\t**Bem vindo ao Software de Gestao Imobiliaria**\n\n\n\t\t\t\t\t[Press Enter]");
            Console.ReadKey();
            Console.Clear();

            while (repeticao == 's')
            {
                int querRepetir = -1;
                char opcao = 'a';
                int erroOpcao = -1;
                char saida = '1';

                while (opcao != '1' && opcao != '2' && opcao != '3' && opcao != '4' && opcao != '5' && opcao != '6' && opcao != '7' && opcao != '8' && opcao != '0')
                {
                    if (erroOpcao == 0)
                    {
                        Console.WriteLine("\n\t\t\tOpção inválida\n");
                    }

                    Console.Write("\n\n\t\tDigite a opção desejada realizar:\n\n\t1 - Adicionar Cliente;\n\t2 - Adicionar Proprietario;\n\t3 - Adicionar Imovel (primeiro deve inserir o proprietario);\n\t4 - Criar Contrato;\n\t5 - Ver Cliente;\n\t6 - Ver Proprietario;\n\t7 - Ver Imovel;\n\t8 - Ver Contrato;\n\t0 - Fechar Software.\n\n\tOpcao:\t");
                    string leitor = Console.ReadLine();

                    if (leitor != "1" && leitor != "2" && leitor != "3" && leitor != "4" && leitor != "5" && leitor != "6" && leitor != "7" && leitor != "8" && leitor != "0")
                    {
                        erroOpcao = 0;
                    }
                    else
                    {
                        opcao = char.Parse(leitor);
                        erroOpcao = 0;
                    }
                    Console.Clear();
                }

                switch (opcao)
                {
                    case '1':
                        Console.Write("\n\n\t\t\t\t\tCriar Ficha Cliente\n\n\n\tInsira o nome do Cliente:\t");
                        string nomeCliente = Console.ReadLine();
                        Console.Write("\n\n\tInsira o numero de contribuinte do Cliente:\t");
                        int contribuinteCliente = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira o contacto telefonico do Cliente:\t");
                        int contactoCliente = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira a data de nascimento do Cliente (aaaa/mm/dd):\t");
                        DateTime nascimentoCliente = DateTime.Parse(Console.ReadLine());

                        //Cria Cliente
                        Cliente c = new Cliente();
                        c.Nome = nomeCliente;
                        c.ContribuinteCliente = contribuinteCliente;
                        c.ContactoCliente = contactoCliente;
                        c.Nascimento = nascimentoCliente;
                        
                        Console.Clear();
                        Console.WriteLine(RegrasImoveis.InsereCliente(c));
                        break;

                    case '2':
                        Console.Write("\n\n\t\t\t\t\tCriar Ficha Proprietario\n\n\n\tInsira o nome do Proprietario:\t");
                        string nomeProprietario = Console.ReadLine();
                        Console.Write("\n\n\tInsira o numero de contribuinte do Proprietario:\t");
                        int contribuinteProprietario = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira o contacto telefonico do Proprietario:\t");
                        int contactoProprietario = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira o iban do Proprietario:\t");
                        string ibanProprietario = Console.ReadLine();

                        ///Cria Proprietario
                        Proprietario p = new Proprietario();
                        p.NomeProp = nomeProprietario;
                        p.ContribuinteProp = contribuinteProprietario;
                        p.ContactoProp = contactoProprietario;
                        p.Iban = ibanProprietario;

                        Console.Clear();
                        Console.WriteLine(RegrasImoveis.InsereProprietario(p));


                        break;

                    case '3':
                        //imovel
                        Console.Write("\n\n\t\t\t\t\tCriar Ficha Imovel\n\n\n\tInsira o valor de identificacao predial:\t");
                        int idPredial = int.Parse(Console.ReadLine());//idmorada==idpredial                       
                        Console.Write("\n\n\tInsira o estado do imovel:\t");
                        string estadoPredial = Console.ReadLine();
                        Console.Write("\n\n\tInsira o valor de aluguer:\t");
                        int valorAluguer = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira o valor de predial:\t");
                        int valorPredial = int.Parse(Console.ReadLine());
                        //morada
                        Console.Write("\n\n\tInsira a rua do imovel:\t");
                        string rua = Console.ReadLine();
                        Console.Write("\n\n\tInsira o numero de porta:\t");
                        int nPorta = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira o codigo postal (sem espacamentos, nem caracteres (Ex:*******)):\t");
                        string codPostal = Console.ReadLine();
                        Console.Write("\n\n\tInsira a localidade do imovel (freguesia, concelho, cidade):\t");
                        string localidade = Console.ReadLine();

                        // Cria Imovel
                        Imovel i = new Imovel();
                        i.IdPredial = idPredial;
                        i.EstadoPredial = estadoPredial;
                        i.ValorAluguer = valorAluguer;
                        i.ValorPredial = valorPredial;
                        //Cria Morada
                        Morada m = new Morada();
                        m.IdMorada = idPredial;
                        m.Rua = rua;
                        m.NPorta = nPorta;
                        m.CodPostal = codPostal;
                        m.Localidade = localidade;

                        Console.Clear();
                        Console.WriteLine(RegrasImoveis.InsereImovel(i, m));

                        break;

                    case '4':
                        Console.WriteLine("\n\n\t\t\t\t\tCriar Contrato\n\n\tInsira o numero de contribuinte do Cliente:\t");
                        int contratoContribuinteCliente = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira o numero de contribuinte do Proprietario:\t");
                        int contratoContribuinteProprietario = int.Parse(Console.ReadLine());
                        Console.Write("\n\n\tInsira a identificaçao predial:\t");//pede idImovel
                        int contratoIdImovel = int.Parse(Console.ReadLine());
                        /*
                        * ***   ***    *****    ***  *******      *****      ******
                        *  *** ***    *** ***   ***  *******     *******     *** ***    TRUMP TRUMP TRUMP TRUMP
                        *   *****     *** ***   ***    ***      ***   ***    ******
                        *    ***       *****    ***    ***     ***     ***   *** ***
                        */

                        Console.Clear();
                        Console.WriteLine("deu//nao deu");
                        break;

                    case '5':

                        Console.Write("\n\n\t\t\t\t\tPesquisar Ficha Cliente\n\n\tInsira o numero de contribuinte do Cliente:\t");
                        int pesquisarContribuinteCliente = int.Parse(Console.ReadLine());

                        /*
                        * ***   ***    *****    ***   *******      *****      ******
                        *  *** ***    *** ***   ***   *******     *******     *** ***
                        *   *****     *** ***   ****    ***      ***   ***    ******
                        *    ***       *****    ****    ***     ***     ***   *** ***
                        */

                        Console.Clear();
                        Console.WriteLine("Apresenta ficha do Cliente\n\n\n\t\t\t[Press Enter]");

                        break;

                    case '6':
                        Console.Write("\n\n\t\t\t\t\tPesquisar Ficha Proprietario\n\n\tInsira o numero de contribuinte do proprietario:\t");
                        int pesquisarContribuinteProprietario = int.Parse(Console.ReadLine());
                        /*
                        * ***   ***    *****    ***  *******      *****      ******
                        *  *** ***    *** ***   ***  *******     *******     *** ***
                        *   *****     *** ***   ***    ***      ***   ***    ******
                        *    ***       *****    ***    ***     ***     ***   *** ***
                        */

                        Console.Clear();
                        Console.WriteLine("Apresenta ficha do proprietario\n\n\n\t\t\t[Press Enter]");

                        break;

                    case '7':
                        Console.Write("\n\n\t\t\t\t\tPesquisar Ficha Imovel\n\n\tInsira a identificaçao predial:\t");//pede idImovel
                        int pesquisarIdImovel = int.Parse(Console.ReadLine());

                        /*
                        * ***   ***    *****    ***  *******      *****      ******
                        *  *** ***    *** ***   ***  *******     *******     *** ***
                        *   *****     *** ***   ***    ***      ***   ***    ******
                        *    ***       *****    ***    ***     ***     ***   *** ***
                        */

                        Console.Clear();
                        Console.WriteLine("Apresenta ficha do Imovel\n\n\n\t\t\t[Press Enter]");

                        break;

                    case '8':
                        Console.Write("\n\n\t\t\t\t\tPesquisar por contrato\n\n\tInsira numero de Contrato:\t");
                        int pesquisarNumeroContrato = int.Parse(Console.ReadLine());

                        /*
                         * ***   ***    *****    ***    *******      *****      ******
                         *  *** ***    *** ***   ***    *******     *******     *** ***
                         *   *****     *** ***   ***      ***      ***   ***    ******
                         *    ***      *** ***   *****    ***     ***********   *** ***
                         *     *        *****    *****    ***    ***       ***  ***  ***
                         */

                        Console.Clear();
                        Console.WriteLine("Apresenta dados de contrato\n\n\n\t\t\t[Press Enter]");
                        break;

                    case '0':
                        querRepetir = -2;
                        Console.WriteLine("Precione Enter para Encerrar\n\n\n\t\t\t[Press Enter]");
                        break;

                    default:
                        Console.WriteLine("\n\t\t\t--------- Erro de Sistema ---------\n\n\n\t\t\t[Press Enter]");
                        querRepetir = 0;
                        saida = '2';
                        break;
                }
                Console.ReadKey();
                Console.Clear();
                int k = -1;
                while (saida != '2')
                {
                    if (k == 0)
                    {
                        Console.WriteLine("\n\t\t\tOpção inválida\n");
                    }
                    if (querRepetir == -1)
                    {
                        Console.WriteLine("\n\t\tDeseja realizar outra operação? (s/n)");
                        string leitor2 = Console.ReadLine();
                        if (leitor2 == "s" || leitor2 == "n")
                        {
                            repeticao = char.Parse(leitor2);
                            saida = '2';
                        }
                        k = 0;
                    }
                    else if (querRepetir == -2)
                    {
                        repeticao = 'n';
                        saida = '2';
                    }
                    Console.Clear();
                }
            }
        }
    }
}