﻿/*
 *  Class Gere Dados
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */

using ObjetosNegocios;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;

namespace Dados
{
    public class GereDados
    {
        #region ATRIBUTOS

        private static List<Imovel> imovel { get; set; } =  new List<Imovel>();
        private static List<Morada> morada { get; set; } = new List<Morada> { };
        private static List<Proprietario> proprietario { get; set; } = new List<Proprietario> ();
        private static List<Cliente> cliente { get; set; } = new List<Cliente>();

        

        #region COMPORTAMENTO
        public GereDados()
        {

        }
        #endregion


        #region PROPRIEDADES

        #endregion

        #region OUTROS METODOS

        //IMOVEL
        /// <summary>
        /// Metodo para Inserir um imovel
        /// </summary>
        /// <param name="i">variavel que vai receber o valor para ser adicionado</param>
        /// <returns></returns>
        public static bool InsereImovel(Imovel i, Morada m)
        { 
               imovel.Add(i);
               morada.Add(m);
               return true;       
        }

        /// <summary>
        /// Metodo para verificar se o Imovel já existe
        /// </summary>
        /// <param name="i">Parametro atribuido ao Imovel</param>
        /// <returns></returns>
        public static bool VerificaImovel (Imovel i)
        {
            return imovel.Contains(i);
        }

        /// <summary>
        /// Procura na Lista Imovel, o primeiro idPredial que seja igual ao id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static Imovel PesquisarImovel (int id)
        {
            return imovel.FirstOrDefault(i => i.IdPredial == id);
        }

        public static string InserePropImovel(Imovel i, Proprietario p)
        {
            
        }

        //MORADA

        public static bool InsereMorada(Morada m)
        {
            morada.Add(m);
            return true;
        }

        public static bool VerificaMorada(Morada m)
        {
            return morada.Contains(m);
        }


        //PROPRIETARIO
        /// <summary>
        /// Metodo para inserir um Proprietario
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool InsereProprietario (Proprietario p)
        {
            proprietario.Add(p);
            return true;
        }

        public static bool VerificarProprietario (Proprietario p)
        {
            return proprietario.Contains(p); 
        }


        //CLIENTE
        /// <summary>
        /// Metodo para Inserir um cliente
        /// </summary>
        /// <param name="c">Variavel que vai receber o valor para ser adicionado</param>
        /// <returns></returns>
        public static bool InsereCliente(Cliente c)
        {
            cliente.Add(c);
           
            return true;

        }

        /// <summary>
        /// Metodo para verificar a existencia de um cliente
        /// </summary>
        /// <param name="ec">Variavel que vai receber o valor para verificar se o cliente já existe</param>
        /// <returns></returns>
        public static bool VerificaCliente(Cliente c)
        {
            return cliente.Contains(c);
        }


        //FICHEIRO IMOVEL
        public static bool GuardaDadosImovel(string f)
        {
            try
            {
                Stream s = File.Open(f, FileMode.Create);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, imovel);
                s.Close();
                return true;
            }
            catch
            {
                throw new Exception("Impossivel aceder a ficheiro..");
            }
        }

        public static bool CarregaDadosImovel(string f)
        {
            try
            {
                Stream s = File.Open(f, FileMode.Open, FileAccess.Read);
                BinaryFormatter b = new BinaryFormatter();
                imovel = (List<Imovel>)b.Deserialize(s);
                s.Close();
                return true;
            }
            catch (Exception e)
            {
                throw new Exception("Erro...:" + e.Message);
            }
        }

        #endregion
        #endregion

    }
}
