﻿using Dados;
using ObjetosNegocios;
using System;
using System.Collections.Generic;


namespace RegrasNegocio
{
    public class RegrasImoveis
    { 
        //IMOVEL

        /// <summary>
        /// Verifica a existencia de um imovel no condominio a partir do metodo ExisteImovel e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="i">Responsável por procurar a variavel inserida pelo user na LIST Imovel</param>
        /// <returns></returns>
        public static string InsereImovel(Imovel i, Morada m)
        {

                if (GereImovel.VerificaImovel(i))
                {
                    return "Imovel já existente!";
                }
                else if (GereProprietario.InserePropImovel(i)==false)
                {
                    return "Ficha de Cliente nao encontrada!";
                }
                else
                {
                    GereImovel.InsereMoradaImovel(i, m);
                    GereImovel.InsereImovel(i, m);
                    return "Imovel inserido com sucesso!";                 
                }

        }


        /// <summary>
        /// Metodo para adicionar um proprietario ao imovel, onde verifica primeiro a existencia do imovel e depois adiciona o Proprietario
        /// </summary>
        /// <param name="i">Parametro atribuido ao imovel</param>
        /// <param name="p">Parametro atribuido ao Proprietario</param>
        /// <returns></returns>
        public static bool AdicionarPropImovel (Imovel i, Proprietario p)
        {
            if (GereImovel.VerificaImovel(i))
            {
                GereProprietario.InsereProprietario(p);
                Console.WriteLine("Proprietário adicionado com sucesso!");
                return true;
            }
            else
            {
                return false; 
            }
        }
        

        public static string PesquisarImovel(int id)
        {
            //GereContrato.VerificaImovel(GereContrato.PesquisarImovel(int id));
            return GereImovel.PesquisarImovel(id);
        }
        //CLIENTE

        /// <summary>
        /// Verifica a existencia de um Cliente no condominio a partir do metodo VerificaCliente e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="c">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static string InsereCliente(Cliente c)
        {
            if (GereCliente.VerificaCliente(c))
            {
                return "Cliente já existente!";
                
            }
            else
            {
                GereCliente.InsereCliente(c);
                return "Cliente inserido com sucesso!";
            }
        }

        public static string PesquisarCliente(int contribuinte)
        {
            return GereCliente.PesquisarCliente(contribuinte);
        }

        //PROPRIETARIO
        public static string InsereProprietario (Proprietario p)
        {

            if (GereProprietario.VerificarProprietario(p))
            {
                return "Proprietario já existente!";
            }
            else
            {
                GereProprietario.InsereProprietario(p);
                return "Proprietario inserido com sucesso!";
            }

        }

        public static string PesquisarProprietario(int contribuinteProp)
        {
            return GereProprietario.PesquisarProprietario(contribuinteProp);
        }



    }
}
