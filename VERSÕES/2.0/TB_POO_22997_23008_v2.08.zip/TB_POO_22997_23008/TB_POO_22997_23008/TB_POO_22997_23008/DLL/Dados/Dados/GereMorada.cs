﻿using ObjetosNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dados
{
    public class GereMorada
    {
        private static List<Morada> morada { get; set; } = new List<Morada>();
        public static bool InsereMorada(Morada m)
        {
            morada.Add(m);
            return true;
        }

        public static bool VerificaMorada(Morada m)
        {
            return morada.Contains(m);
        }
    }
}
