﻿using ObjetosNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dados
{
    public  class GereProprietario
    {
        private static List<Proprietario> proprietario { get; set; } = new List<Proprietario>();

        public static bool InserePropImovel(Imovel i)
        {
            foreach (var prop in proprietario)
            {
                if (i.Proprietario == prop.ContribuinteProp)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool InsereProprietario(Proprietario p)
        {
            proprietario.Add(p);
            return true;
        }

        public static bool VerificarProprietario(Proprietario p)
        {
            return proprietario.Contains(p);
        }

        public static string PesquisarProprietario(int contribuinteProp)
        {

            foreach (var p in proprietario)
            {
                if (p.ContribuinteProp == contribuinteProp)
                {
                    return ImprimirInformacoesProprietario(p);  // Para de pesquisar após encontrar o primeiro imóvel com o endereço especificado
                }
            }
            return "";
        }


        private static string ImprimirInformacoesProprietario(Proprietario p)
        {
            return "Nome:" + p.NomeProp + " Numero de Contribuinte:" + p.ContribuinteProp + " IBAN:" + p.Iban + " COntacto:" + p.ContactoProp;

        }


    }
}
