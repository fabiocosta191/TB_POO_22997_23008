﻿using ObjetosNegocios;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Dados
{
    public class GereImovel
    {
        private static List<Imovel> imovel { get; set; } = new List<Imovel>();


        public static bool InsereImovel(Imovel i, Morada m)
        {
            if (GereProprietario.InserePropImovel(i) == true)
            {
                imovel.Add(i);
                return true;
            }
            return false;

        }

        /// <summary>
        /// Metodo para verificar se o Imovel já existe
        /// </summary>
        /// <param name="i">Parametro atribuido ao Imovel</param>
        /// <returns></returns>
        public static bool VerificaImovel(Imovel i)
        {
            return imovel.Contains(i);

        }

        /// <summary>
        /// Procura na Lista Imovel, o primeiro idPredial que seja igual ao id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static string PesquisarImovel(int id)
        {

            foreach (var i in imovel)
            {
                if (i.IdPredial == id)
                {
                    return ImprimirInformacoesImovel(i); ; // Para de pesquisar após encontrar o primeiro imóvel com o endereço especificado
                }
            }
            return "";
        }

        /// <summary>
        /// Imprime Informações do Imovel
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        private static string ImprimirInformacoesImovel(Imovel i)
        {
            return "Valor Predial:" + i.ValorPredial + " Valor de aluguer:" + i.ValorAluguer + "  Estado de Imovel" + i.EstadoPredial + " Contribuinte do Proprietario" + i.Proprietario + " " + i.Morada;

            // Adicione outras propriedades conforme necessário
        }


        /// <summary>
        /// Insere Morada no imovel ao igualar valores
        /// </summary>
        /// <param name="i"></param>
        /// <param name="m"></param>
        public static void InsereMoradaImovel(Imovel i, Morada m)
        {
            i.Morada = m.MoradaFinal;
        }

        //FICHEIRO IMOVEL
        public static bool GuardaDadosImovel(string f)
        {
            try
            {
                Stream s = File.Open(f, FileMode.Create);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, imovel);
                s.Close();
                return true;
            }
            catch
            {
                throw new Exception("Impossivel aceder a ficheiro..");
            }
        }

        public static bool CarregaDadosImovel(string f)
        {
            try
            {
                Stream s = File.Open(f, FileMode.Open, FileAccess.Read);
                BinaryFormatter b = new BinaryFormatter();
                imovel = (List<Imovel>)b.Deserialize(s);
                s.Close();
                return true;
            }
            catch (Exception e)
            {
                throw new Exception("Erro...:" + e.Message);
            }
        }

    }
}
