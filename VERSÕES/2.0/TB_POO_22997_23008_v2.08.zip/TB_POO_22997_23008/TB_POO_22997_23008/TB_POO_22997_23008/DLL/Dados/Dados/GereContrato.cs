﻿/*
 *  Class Gere Dados
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */

using ObjetosNegocios;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Dados
{
    public class GereContrato
    {
        #region ATRIBUTOS

        private static List<Contrato> contrato { get; set; } = new List<Contrato> ();

        

        #region COMPORTAMENTO
        public GereContrato()
        {

        }
        #endregion


        #region PROPRIEDADES

        #endregion

        #region OUTROS METODOS


        // CONTRATO
        public static bool InsereContrato(Contrato con)
        {
            contrato.Add(con); 
            return true; 
        }
        
        public static bool VerificaContrato(Contrato con)
        {
            return contrato.Contains(con);
        }

        #endregion
        #endregion
    }
}
