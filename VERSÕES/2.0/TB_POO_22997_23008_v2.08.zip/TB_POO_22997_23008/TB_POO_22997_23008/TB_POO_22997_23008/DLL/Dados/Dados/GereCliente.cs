﻿using ObjetosNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dados
{
    public class GereCliente
    {

        private static List<Cliente> cliente { get; set; } = new List<Cliente>();
      
        public static bool InsereCliente(Cliente c)
        {
            cliente.Add(c);

            return true;

        }

        /// <summary>
        /// Metodo para verificar a existencia de um cliente
        /// </summary>
        /// <param name="ec">Variavel que vai receber o valor para verificar se o cliente já existe</param>
        /// <returns></returns>
        public static bool VerificaCliente(Cliente c)
        {
            return cliente.Contains(c);
        }

        public static string PesquisarCliente(int contribuinte)
        {

            foreach (var cliente in cliente)
            {
                if (cliente.ContribuinteCliente == contribuinte)
                {
                    return ImprimirInformacoesCliente(cliente); ; // Para de pesquisar após encontrar o primeiro imóvel com o endereço especificado
                }
            }
            return "";
        }
        private static string ImprimirInformacoesCliente(Cliente c)
        {
            return "Nome Cliente:" + c.Nome + " Data de Nascimento:" + c.Nascimento + " Numero de Contribuinte:" + c.ContribuinteCliente + " Contacto:" + c.ContactoCliente;

            // Adicione outras propriedades conforme necessário
        }
    }
}
