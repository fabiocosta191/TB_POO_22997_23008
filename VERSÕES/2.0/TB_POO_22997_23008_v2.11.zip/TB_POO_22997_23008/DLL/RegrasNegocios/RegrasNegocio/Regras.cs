﻿/*
 *  Class Regras de Negocio (I/O)
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */

using Dados;
using ObjetosNegocios;
using System;


namespace RegrasNegocio
{
    public class Regras
    {
        //IMOVEL

        /// <summary>
        /// Chama os metodo para verificar o imovel e caso o mesmo não exista, insere o proprietario no imovel, insere morada no imovel e cria um imovel
        /// </summary>
        /// <param name="i">Imovel</param>
        /// <param name="m">Morada</param>
        /// <returns></returns>
        public static string InsereImovel(Imovel i, Morada m)
        {

                if (GereImovel.VerificaImovel(i))
                {
                    return "Imovel já existente!";
                }
                else if (GereProprietario.InserePropImovel(i)==false)
                {
                    return "Ficha de Cliente nao encontrada!";
                }
                else
                {
                    GereImovel.InsereMoradaImovel(i, m);
                    GereImovel.InsereImovel(i);
                    return "Imovel inserido com sucesso!";                 
                }
        }


        /// <summary>
        /// Vai retornar o metodo para pesquisar imovel
        /// </summary>
        /// <param name="id">valor fornecido</param>
        /// <returns></returns>
        public static string PesquisarImovel(int id)
        {
            return GereImovel.PesquisarImovel(id);
        }


        ///CLIENTE

        /// <summary>
        /// Verifica a existencia de um Cliente no condominio a partir do metodo VerificaCliente e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="c">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static string InsereCliente(Cliente c)
        {
            if (GereCliente.VerificaCliente(c))
            {
                return "Cliente já existente!";  
            }
            else
            {
                GereCliente.InsereCliente(c);
                return "Cliente inserido com sucesso!";
            }
        }

        /// <summary>
        /// Vai retornar o metodo para pesquisar cliente
        /// </summary>
        /// <param name="contribuinte">Valor fornecido</param>
        /// <returns></returns>
        public static string PesquisarCliente(int contribuinte)
        {
            return GereCliente.PesquisarCliente(contribuinte);
        }

        ///PROPRIETARIO

        /// <summary>
        /// Chama o metodo para verificar se o proprietario existe, caso não exista vai inserir o mesmo.
        /// </summary>
        /// <param name="p">Proprietario</param>
        /// <returns></returns>
        public static string InsereProprietario (Proprietario p)
        {

            if (GereProprietario.VerificarProprietario(p))
            {
                return "Proprietario já existente!";
            }
            else
            {
                GereProprietario.InsereProprietario(p);
                return "Proprietario inserido com sucesso!";
            }

        }

        /// <summary>
        /// Vai retornar o metodo para pesquisar proprietario
        /// </summary>
        /// <param name="contribuinteProp">Valor fornecido</param>
        /// <returns></returns>
        public static string PesquisarProprietario(int contribuinteProp)
        {
            return GereProprietario.PesquisarProprietario(contribuinteProp);
        }


        ///CONTRATO
        
        /// <summary>
        /// Chama os metodos para para inserir no contrato caso as fichas desses dados existam ele vai criar um novo contrato
        /// </summary>
        /// <param name="con"></param>
        /// <returns></returns>
        public static string DadoContrato(Contrato con)
        {

            if (GereImovel.PesquisarImovelContrato(con.IdcPredial) == false)
            {
                return "Ficha Imovel Inexistente";
            }
            else if (GereCliente.PesquisarClienteContrato(con.ContribuinteCCliente) == false)
            {
                return "Ficha Cliente Inexistente";
            }
            else if (GereProprietario.PesquisarProprietarioContrato(con.ProprietarioC) == false)
            {
                return "Ficha Proprietario Inexistente";
            }
            else 
            {
                GereContrato.ContaNumeroContrato(con);
                GereContrato.DadoContrato(con);
                GereContrato.InsereContrato(con);
                return "Contrato Inserido com sucesso!! O numero de contrato é: " + con.NumContrato; 
            }
        }

        /// <summary>
        /// Chama o metodo para pesquisar contrato
        /// </summary>
        /// <param name="numContrato">Valor fornecido</param>
        /// <returns></returns>
        public static string PesquisarContrato(int numContrato)
        {
            return GereContrato.PesquisarContrato(numContrato);
        }

        
        public static void CarregaInformacao()
        {   
            GereImovel.CarregaDadosImovel("backimovel.bin");
            GereCliente.CarregaDadosCliente("backcliente.bin");
            GereContrato.CarregaDadosContrato("backcontrato.bin");
            GereProprietario.CarregaDadosProprietario("backproprietario.bin");
        }
        public static void GuardaInformacao()
        {
            GereImovel.GuardaDadosImovel("backimovel.bin");
            GereCliente.GuardaDadosCliente("backcliente.bin");
            GereContrato.GuardaDadosContrato("backcontrato.bin");
            GereProprietario.GuardaDadosProprietario("backproprietario.bin");
        }

    }
}
