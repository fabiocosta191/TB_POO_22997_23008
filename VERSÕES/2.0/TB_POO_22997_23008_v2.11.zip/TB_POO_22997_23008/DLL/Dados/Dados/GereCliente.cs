﻿/*
 *  Class Gere Cliente
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 15/12/2023
 */
using ObjetosNegocios;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Dados
{
    public class GereCliente
    {
        #region Atributos
        /// <summary>
        /// Criação de uma List Cliente
        /// </summary>
        private static List<Cliente> cliente { get; set; } = new List<Cliente>();
        #endregion

        #region Comportamento
        #region Construtores

        public GereCliente() 
        {
            
        }
        #endregion

        #region Outros Metodos
        /// <summary>
        /// Insere um cliente na List
        /// </summary>
        /// <param name="c">Cliente</param>
        /// <returns></returns>
        public static bool InsereCliente(Cliente c)
        {
            cliente.Add(c);

            return true;
        }

        /// <summary>
        /// Verifica a existência de um cliente na List
        /// </summary>
        /// <param name="c">Cliente</param>
        /// <returns></returns>
        public static bool VerificaCliente(Cliente c)
        {
            return cliente.Contains(c);
        }

        /// <summary>
        /// Encontra o primeiro cliente na List cujo contribuinte seja igual ao valor fornecido e chama o metodo ImprimirInformacoesCliente para imprimir as informações.
        /// </summary>
        /// <param name="contribuinte">Valor fornecido</param>
        /// <returns></returns>
        public static string PesquisarCliente(int contribuinte)
        {

            foreach (Cliente c in cliente)
            {
                if (c.ContribuinteCliente == contribuinte)
                {
                    return ImprimirInformacoesCliente(c); 
                }
            }
            return "Cliente nao encontrado!!!";
        }

        /// <summary>
        /// Imprime as informações do cliente
        /// </summary>
        /// <param name="c">Cliente</param>
        /// <returns></returns>
        private static string ImprimirInformacoesCliente(Cliente c)
        {
            return "Nome Cliente:" + c.Nome + " Data de Nascimento:" + c.Nascimento + " Numero de Contribuinte:" + c.ContribuinteCliente + " Contacto:" + c.ContactoCliente;
        }

        /// <summary>
        /// Encontra o primeiro cliente na List cujo contribuinte seja igual ao valor fornecido.
        /// </summary>
        /// <param name="contribuinte">Valor fornecido</param>
        /// <returns></returns>
        public static bool PesquisarClienteContrato(int contribuinte)
        {
            foreach (Cliente c in cliente)
            {
                if (c.ContribuinteCliente == contribuinte)
                {
                    return true; 
                }
            }
            return false;
        }

        //METODO PARA GUARDAR DADO Cliente

        public static void GuardaDadosCliente(string caminhoArquivo)
        {
            try
            {
                using (Stream s = File.Open(caminhoArquivo, FileMode.Create))
                {
                    BinaryFormatter b = new BinaryFormatter();
                    b.Serialize(s, cliente);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Impossível acessar arquivo.", ex);
            }
        }

        public static void CarregaDadosCliente(string caminhoArquivo)
        {
            if (File.Exists(caminhoArquivo) && new FileInfo(caminhoArquivo).Length > 0)
            {
                using (Stream s = File.Open(caminhoArquivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter b = new BinaryFormatter();
                    cliente = (List<Cliente>)b.Deserialize(s);
                }
            }
            else
            {
                cliente = new List<Cliente>();
            }
        }
        #endregion
        #endregion
    }
}
