﻿/*
 *  Interface Geral
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
namespace Interfaces
{
    public interface IImovel
    {
       int IdPredial { get; set; }
    }

    public interface IMorada
    {
        int IdMorada { get; set;}
    }

    public interface ICliente
    {
        int ContribuinteCliente { get; set; } 
    }

    public interface IProprietario
    {
        int ContribuinteProp { get; set; }
    }
}
