﻿/*
 *  Class Cliente
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using System;
using Interfaces;

namespace ObjetosNegocios
{
    public class Cliente : ICliente
    {
        #region ATRIBUTOS
        private string nome;
        private int contribuinteCliente;
        private int contactoCliente;
        private DateTime nascimento;
        #endregion

        #region COMPORTAMENTO
        #region CONSTRUTORES
        public Cliente () 
        {
             nome = string.Empty;
            contribuinteCliente = 0;
        }

        public Cliente (string nome, int contribuinteCliente, DateTime nascimento)
        {
            this.nome = nome;
            this.contribuinteCliente = contribuinteCliente;
            this.nascimento = nascimento;
        }

        #endregion
        #region PROPRIEDADES
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }       
        public int ContribuinteCliente
        {
            get { return contribuinteCliente; }
            set { contribuinteCliente = value; }
        }
        public DateTime Nascimento
        { 
            get { return nascimento; } 
            set { nascimento = value; } 
        }
        #endregion

        #region OUTROS METODOS

        #endregion
        #endregion
    }
}
