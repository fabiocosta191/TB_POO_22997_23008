﻿using Dados;
using ObjetosNegocios;
using System;


namespace RegrasNegocio
{
    public class RegrasImoveis
    { 
        /// <summary>
        /// Verifica a existencia de um imovel no condominio a partir do metodo ExisteImovel e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="i">Responsável por procurar a variavel inserida pelo user na LIST Imovel</param>
        /// <returns></returns>
        public static bool InsereImovel(Imovel i)
        {
            
            if (GereDados.VerificaImovel(i))
            {
                Console.WriteLine("Imovel já existente!");
                return false;
            }
            else
            { 
                GereDados.InsereImovel(i); 
                Console.WriteLine("Imovel inserido com sucesso!"); 
                return true;
            }

        }

        /// <summary>
        /// Metodo para adicionar uma morada ao imovel, onde verifica primeiro a existencia do imovel e depois adiciona a morada
        /// </summary>
        /// <param name="i">Parametro atribuido ao imovel</param>
        /// <param name="m">Parametro atribuido a morada</param>
        /// <returns></returns>
        public static bool AdicionarMoradaImovel(Imovel i, Morada m)
        {
            if (GereDados.VerificaImovel(i))
            {
                GereDados.InsereMorada(m);
                Console.WriteLine("Morada adicionada com sucesso!");
                return true;
            }
            else
            {
                return false; 
            }
        }

        /// <summary>
        /// Metodo para adicionar um proprietario ao imovel, onde verifica primeiro a existencia do imovel e depois adiciona o Proprietario
        /// </summary>
        /// <param name="i">Parametro atribuido ao imovel</param>
        /// <param name="p">Parametro atribuido ao Proprietario</param>
        /// <returns></returns>
        public static bool AdicionarPropImovel (Imovel i, Proprietario p)
        {
            if (GereDados.VerificaImovel(i))
            {
                GereDados.InsereProprietario(p);
                Console.WriteLine("Proprietário adicionado com sucesso!");
                return true;
            }
            else
            {
                return false; 
            }
        }

        public static bool PesquisarImovel(int id)
        {
            Imovel iProc = GereDados.PesquisarImovel(id);

            if (iProc != null)
            {
                Console.WriteLine("Id{0}",iProc.IdPredial);
                Console.WriteLine("Estado {0}",iProc.EstadoPredial);
                Console.WriteLine("Valor {0}",iProc.ValorAluguer);
            }
            else
            {
                Console.WriteLine("Imovel com id {0} não foi encontrado!", id);
            }
            return false; 
        }

        /// <summary>
        /// Verifica a existencia de um Cliente no condominio a partir do metodo VerificaCliente e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="c">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static bool InsereCliente(Cliente c)
        {
            if (GereDados.VerificaCliente(c))
            {
                Console.WriteLine("Cliente já existente!");
                return false;
            }
            else
            {
                GereDados.InsereCliente(c); 
                Console.WriteLine("Cliente inserido com sucesso!");
                return true;
            }
        }
    }
}
