﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegrasNegocio;
using ObjetosNegocios; 

namespace Programa_Teste
{
    public class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            while (a != 4)
            {
                // Cria Imovel
                Imovel i = new Imovel();
                i.IdPredial = 1;
                i.ValorPredial = 2;
                i.ValorAluguer = 3;
                int idPesq = 2; 
                bool procImovel = RegrasImoveis.PesquisarImovel(idPesq);
                
                /*///Cria Proprietario
                Proprietario p = new Proprietario();
                //Cria Morada
                Morada m = new Morada();
                //Cria Cliente
                Cliente c = new Cliente();

                // Cria novo imovel
                bool addImovel = RegrasImoveis.InsereImovel(i);
                // Adiciona Morada ao Imovel
                bool addMorada = RegrasImoveis.AdicionarMoradaImovel(i,m);
                // Adciona Prop ao Imovel
                bool addProp = RegrasImoveis.AdicionarPropImovel(i,p);

                
               
                Console.WriteLine("insere");
                int inteiroNumero = int.Parse(Console.ReadLine());
                i.IdPredial = inteiroNumero;
                Console.WriteLine("Qual a ");
                

                bool aux = RegrasImoveis.InsereImovel(i);
                Console.WriteLine("ola eu e o meu coleha {0}", aux);
                Console.ReadKey();
                a++;
                */
            }
        }
    }
}
