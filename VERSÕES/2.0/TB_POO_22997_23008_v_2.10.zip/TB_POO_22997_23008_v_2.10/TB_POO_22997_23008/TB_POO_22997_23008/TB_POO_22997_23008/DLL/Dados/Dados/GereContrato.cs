﻿/*
 *  Class Gere Contrato
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */

using ObjetosNegocios;
using System.Collections.Generic;

namespace Dados
{
    public class GereContrato
    {
        #region Atributos

        private static List<Contrato> contrato { get; set; } = new List<Contrato>();
        #endregion

        #region Comportamento
        public GereContrato()
        {
        }

        #region Outros Metodos

        /// <summary>
        /// Insere um Contrato na List
        /// </summary>
        /// <param name="con">Contrato</param>
        /// <returns></returns>
        public static bool InsereContrato(Contrato con)
        {
            contrato.Add(con);
            return true;
        }

        /// <summary>
        /// Concatena todas as informações geradas sobre imovel, proprietario e cliente e atribui a string resultante ao ContratoFinal (Contrato)
        /// </summary>
        /// <param name="con"></param>
        public static void DadoContrato(Contrato con)
        {
            con.ContratoFinal = "Imovel:\n"+ GereImovel.PesquisarImovel(con.IdcPredial)+"\nProprietario:\n"+GereProprietario.PesquisarProprietario(con.ProprietarioC)+"\nCliente:\n" + GereCliente.PesquisarCliente(con.ContribuinteCCliente)  ;
        }

        /// <summary>
        /// Acessa ao ultimo elemento na List e incremeenta + ao valor de NumContrato
        /// </summary>
        /// <param name="con"></param>
        public static void ContaNumeroContrato(Contrato con)
        {
            if (contrato.Count > 0)
            {
                // Acesse o último elemento e incremente o valor do atributo 'NumContrato'
                con.NumContrato = contrato[contrato.Count - 1].NumContrato + 1;
            }
            else
            {
                // Lida com o caso em que a lista está vazia
                con.NumContrato = 1;
            }
        }

        /// <summary>
        /// Encontra o primeiro contrato na List cujo NumContrato seja igual ao valor fornecido e chama o metodo ImprimirInformacoesContrato para imprimir as informações.
        /// </summary>
        /// <param name="numcontrato">Valor forncedio</param>
        /// <returns></returns>
        public static string PesquisarContrato(int numcontrato)
        {

            foreach (var con in contrato)
            {
                if (con.NumContrato == numcontrato)
                {
                    return ImprimirInformacoesContrato(con); 
                }
            }
            return "Contrato nao encontrado!!!";
        }

        /// <summary>
        /// Imprimir informações do contrato
        /// </summary>
        /// <param name="con"></param>
        /// <returns></returns>
        private static string ImprimirInformacoesContrato(Contrato con)
        {
            return "Contrato Nº"+con.NumContrato+"\n"+con.ContratoFinal;

        }

        #endregion
        #endregion
    }

}
    