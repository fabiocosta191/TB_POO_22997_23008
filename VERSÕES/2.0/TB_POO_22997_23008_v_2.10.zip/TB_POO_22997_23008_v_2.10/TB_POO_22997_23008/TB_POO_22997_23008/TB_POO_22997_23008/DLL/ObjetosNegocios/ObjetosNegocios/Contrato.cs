﻿/*
 *  Class Contrato
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using System.Runtime.CompilerServices;

namespace ObjetosNegocios
{
    public class Contrato
    {
        #region Atributos
        private int numContrato;
        private int contribuinteCCliente;
        private int idcPredial;
        private int proprietarioC;
        private string contratoFinal;


        #endregion

        #region Comportamento
        #region Construtores
        public Contrato()
        {

        }
        public Contrato(int numContrato, int ContribuinteCCliente, int idcPredial, int proprietarioC, string contratoFinal)
        {
            this.numContrato = numContrato;
            this.ContribuinteCCliente = ContribuinteCCliente;
            this.idcPredial = idcPredial;
            this.proprietarioC = proprietarioC;
            this.contratoFinal = contratoFinal;        
        }

        #endregion
        #region Propriedades
        public int NumContrato
        {
            get { return numContrato; }
            set { numContrato = value; }
        }

        public int ContribuinteCCliente
        {
            get { return contribuinteCCliente; }
            set { contribuinteCCliente = value; }
        }
        public int IdcPredial
        {
            get { return idcPredial; }
            set { idcPredial = value; }
        }

        public int ProprietarioC
        {
            get { return proprietarioC; }
            set { proprietarioC = value; }
        }

        public string ContratoFinal
        {
            get { return contratoFinal; }
            set { contratoFinal = value; }
        }
        #endregion

        #region OUTROS METODOS

        /// <summary>
        /// Vai compararar a propriedade numContrato de dois objetos Contrato para ver se são iguais.
        /// </summary>
        /// <param name="obj">Objeto</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj is Contrato other)
            {
                return numContrato == other.numContrato;
            }
            return false;
        }

        /// <summary>
        /// Vai retornar o código hash especifico da instância e somar +1 ao numContrato.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return numContrato.GetHashCode();
            numContrato++; 
        }
        #endregion
        #endregion
    }
}
