﻿/*
 *  Class Gere Imovel
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 15/12/2023
 */

using ObjetosNegocios;
using System.Collections.Generic;
using System.IO;
using System;
using System.Runtime.Serialization.Formatters.Binary;

namespace Dados
{
    [Serializable]
    public class GereImovel
    {
        
        #region Atributos
        private static List<Imovel> imovel { get; set; } = new List<Imovel>();
        #endregion
        #region Comportamento
        #region Contrutores
        public GereImovel()
        {
        }
        #endregion


        #region Outros Metodos
        /// <summary>
        /// Associa um proprietario ao Imove, caso seja bem sucedido vai adicionar um imovel a List
        /// </summary>
        /// <param name="i">Imovel</param>
        /// <returns></returns>
        public static bool InsereImovel(Imovel i)
        {
            if (GereProprietario.InserePropImovel(i) == true)
            {
                imovel.Add(i);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Copia informação de MoradaFinal (Morada) para Morada (Imovel)
        /// </summary>
        /// <param name="i">Imovel</param>
        /// <param name="m">Morada</param>
        public static void InsereMoradaImovel(Imovel i, Morada m)
        {
            i.Morada = m.MoradaFinal;
        }

        /// <summary>
        /// Verifica a existência de um Imovel na List
        /// </summary>
        /// <param name="i">Imovel</param>
        /// <returns></returns>
        public static bool VerificaImovel(Imovel i)
        {
            return imovel.Contains(i);
        }

        /// <summary>
        /// Encontra o primeiro imovel na List cujo idPredial seja igual ao valor fornecido e chama o metodo ImprimirInformacoesImovel para imprimir as informações.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static string PesquisarImovel(int id)
        {
            foreach (var i in imovel)
            {
                if (i.IdPredial == id)
                {
                    return ImprimirInformacoesImovel(i);
                }
            }
            return "Imovel nao encontrado!!!";
        }

        /// <summary>
        /// Imprime Informações do Imovel
        /// </summary>
        /// <param name="i">Imovel</param>
        /// <returns></returns>
        private static string ImprimirInformacoesImovel(Imovel i)
        {
            return "Valor Predial:" + i.ValorPredial + " Valor de aluguer:" + i.ValorAluguer + "  Estado de Imovel" + i.EstadoPredial + " Contribuinte do Proprietario" + i.Proprietario + " " + i.Morada;
        }

        /// <summary>
        /// Encontra o primeiro imovel na List cujo idPredial seja igual ao valor fornecido.
        /// </summary>
        /// <param name="id">Valor fornecido</param>
        /// <returns></returns>
        public static bool PesquisarImovelContrato(int id)
        {

            foreach (var i in imovel)
            {
                if (i.IdPredial == id)
                {
                    return true;
                }
            }
            return false;
        }


        /*
        //METODO PARA GUARDAR DADO IMOVEL - NÃO IMPLEMENTADA FALTA TEMPO
         public static void GuardaDadosImovel(string f)
         {
            try
            {
                Stream s = File.Open(f, FileMode.Create);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, imovel);
                s.Close();
                //return true;
            }
            catch
            {
                throw new Exception("Impossivel aceder a ficheiro..");
            }
         }

         public static void CarregaDadosImovel(string f)
         {
            try
            {
                Stream s = File.Open(f, FileMode.Open, FileAccess.Read);
                BinaryFormatter b = new BinaryFormatter();
                imovel = (List<Imovel>)b.Deserialize(s);
                s.Close();
                //return true;
            }
            catch (Exception e)
            {
                throw new Exception("Erro...:" + e.Message);
            }
         }*/
       
        #endregion
        #endregion
    }
}
