﻿/*
 *  Class Gere Morada
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 15/12/2023
 */
using ObjetosNegocios;
using System.Collections.Generic;

namespace Dados
{
    public class GereMorada
    {
        #region Atributos
        private static List<Morada> morada { get; set; } = new List<Morada>();
        #endregion

        #region Comportamento
        #region Construtores
        public GereMorada() 
        { 
        }
        #endregion
        #endregion
        #region Outros Metodos

        /// <summary>
        /// Insere Morada na List
        /// </summary>
        /// <param name="m">Morada</param>
        /// <returns></returns>
        public static bool InsereMorada(Morada m)
        {
            morada.Add(m);
            return true;
        }

        #endregion
    }
}
