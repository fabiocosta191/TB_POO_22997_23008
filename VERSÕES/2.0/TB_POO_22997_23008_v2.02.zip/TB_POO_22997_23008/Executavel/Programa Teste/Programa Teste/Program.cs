﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegrasNegocio;
using ObjetosNegocios; 

namespace Programa_Teste
{
    class Program
    {
        static void Main(string[] args)
        {

            Imovel i = new Imovel();  
            i.IdPredial = 1;


            bool aux = RegrasCondominio.InsereImovel(i);

            Console.WriteLine("ola eu e o meu coleha {0}", aux);
            Console.ReadKey();
        }
    }
}
