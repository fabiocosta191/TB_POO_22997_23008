﻿using Dados;
using ObjetosNegocios;
using System;


namespace RegrasNegocio
{
    public class RegrasCondominio
    {
        
        /// <summary>
        /// Verifica a existencia de um imovel no condominio a partir do metodo ExisteImovel e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="i">Responsável por procurar a variavel inserida pelo user na LIST Imovel</param>
        /// <returns></returns>
        public static bool InsereImovel(Imovel i)
        {
            if (GereDados.ExisteImovel(i.IdPredial))
            {
                Console.WriteLine("Imovel já existente!");
                return false;
            }
            else
            { 
                GereDados.InsereImovel(i); Console.WriteLine("Imovel inserido com sucesso!"); 
                return true;
            }
        }
      

        /// <summary>
        /// Verifica a existencia de um Cliente no condominio a partir do metodo ExisteCliente e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="c">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static bool InsereCliente(Cliente c)
        {
            if (GereDados.ExisteCliente(c.ContribuinteCliente))
            {
                Console.WriteLine("Cliente já existente!");
                return false;
            }
            else
            {
                GereDados.InsereCliente(c); Console.WriteLine("Cliente inserido com sucesso!");
                return true;
            }
        }

        /// <summary>
        /// Verifica a existencia de um Proprietario no condominio a partir do metodo ExisteProprietario e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="p">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static bool InsereProprietario (Proprietario p) 
        {
            if(GereDados.ExisteProprietario(p.ContribuinteProp))
            {
                Console.WriteLine("Proprietário já existente!");
                return false;
            }
            else
            {
                GereDados.InsereProprietario(p); Console.WriteLine("Proprietário inserido com sucesso!");
                return true;
            }
        }
    }
}
