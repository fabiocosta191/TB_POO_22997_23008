﻿/*
 *  Class Proprietario
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using Interfaces;
using System;

namespace ObjetosNegocios
{
    [Serializable]
    public class Proprietario : IProprietario
    {
        #region ATRIBUTOS
        private string nomeProp;
        private string iban;
        private int contribuinteProp;
        #endregion

        #region COMPORTAMENTO
        #region CONSTRUTORES
        public Proprietario() 
        {
            nomeProp = string.Empty;
            iban = string.Empty;
            contribuinteProp = 0;
        }
        public Proprietario (string nomeProp, string iban, int contribuinteProp)
        {
            this.nomeProp = nomeProp;
            this.iban = iban;
            this.contribuinteProp = contribuinteProp;
        }
        #endregion
        #region PROPRIEDADES
        public string NomeProp
        {
            get { return nomeProp; }
            set { nomeProp = value; }
        }
        public string Iban
        {
            get { return iban; }
            set { iban = value; }
        }
        public int ContribuinteProp
        {
            get { return contribuinteProp; }
            set { contribuinteProp = value;}
        }
        #endregion

        #region OUTROS METODOS
        #endregion

        #endregion
    }
}
