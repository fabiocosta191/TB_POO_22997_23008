﻿/*
 *  Class Imovel
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 05/12/2023
 */
using Interfaces;
using System.Collections.Generic;

namespace ObjetosNegocios
{
    public class Imovel : IImovel
    {
        #region ATRIBUTOS
        private int idPredial;
        private string estadoPredial;
        private int valorAluguer;
        private int valorPredial;
        private List<Morada> morada;


        #endregion
        #region COMPORTAMENTO

        #region CONSTRUTORES
        public Imovel()
        {
            morada = new List<Morada>();
        }

      /*  public Imovel(string estadoPredial, int idPredial, int valorAluguer, int valorPredial)
        {
            this.estadoPredial = estadoPredial;
            this.idPredial =  idPredial;
            this.valorAluguer = valorAluguer;
            this.valorPredial = valorPredial;      
        }
      */

        #endregion
        #region PROPRIEDADES
        public int IdPredial
        {
            get { return idPredial; }
            set { idPredial = value; }
        }
        public string EstadoPredial
        {
            get { return estadoPredial; }
            set { estadoPredial = value; }
        }
        public int ValorAluguer
        {
            get { return valorAluguer; }
            set { valorAluguer = value; }
        }
        public int ValorPredial
        {
            get { return valorPredial; }
            set { valorPredial = value; }
        }
        public List<Morada> Morada 
        { 
            get { return morada; }
            set { morada = value; }
        }
        #endregion

        #region OUTROS METODOS



        #endregion
        #endregion
    }
}
