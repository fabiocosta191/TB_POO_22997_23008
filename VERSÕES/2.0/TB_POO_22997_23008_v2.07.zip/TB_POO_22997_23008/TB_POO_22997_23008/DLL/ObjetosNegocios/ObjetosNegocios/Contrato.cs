﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosNegocios
{
    public class Contrato
    {
        #region Atributos
        private int numContrato;
        private int contribuinteCCliente;
        private int idcPerdial;
        private int idcMorada;
        private int proprietarioC;

        #endregion

        #region Comportamento
        #region Construtores
        public Contrato()
        {

        }
        public Contrato(int numContrato)
        {
            this.numContrato = numContrato;
            
        }
        #endregion
        #region Propriedades
        public int NumContrato
        {
            get { return numContrato; }
            set { numContrato = value; }
        }

        public int ContribuinteCCliente
        {
            get { return contribuinteCCliente; }
            set { contribuinteCCliente = value; }
        }

        public int IdcMorada
        {
            get { return idcPerdial; }
            set { idcPerdial = value; }
        }   

        public int IdcPredial
        {
            get { return idcMorada; }
            set { idcMorada = value; }
        }

        public int ProprietarioC
        {
            get { return proprietarioC; }
            set { proprietarioC = value; }
        }
        #endregion

        #region OUTROS METODOS
        public override bool Equals(object obj)
        {
            if (obj is Contrato other)
            {
                return numContrato == other.numContrato;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return numContrato.GetHashCode();
            numContrato++; 
        }
        #endregion
        #endregion
    }
}
