﻿namespace Interfaces
{
    public interface IImovel
    {
       int IdPredial { get; set; }
    }

    public interface IMorada
    {
        int IdMorada { get; set;}
    }

    public interface ICliente
    {
        int ContribuinteCliente { get; set; } 
    }

    public interface IProprietario
    {
        int ContribuinteProp { get; set; }
    }
}
