﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using ObjetosNegocios;

namespace Dados
{
    public class Condominio
    {
        #region ATRIBUTOS
        
        private static List<Imovel> imovel;
        private static List<Morada> morada;
        private static List<Cliente> cliente;
        private static List<Proprietario> proprietario;

        #region COMPORTAMENTO
        public Condominio()
        {

        }
        #endregion

        #region PROPRIEDADES

        #endregion

        #region OUTROS METODOS

        //IMOVEL
        /// <summary>
        /// Metodo para Inserir um imovel
        /// </summary>
        /// <param name="i">variavel que vai receber o valor para ser adicionado</param>
        /// <returns></returns>
        public static bool InsereImovel(Imovel i)
        {
            if (imovel.Contains(i))
            { 
                return false;
            }
            else
            {
                imovel.Add(i);
                return true;
            }
        }

        /// <summary>
        /// Metodo para vertificar Imovel na classe Regras Negocio
        /// </summary>
        /// <param name="ei">Variavel que vai receber o valor para verificar se o imovel já existe</param>
        /// <returns></returns>
        public static bool ExisteImovel(int ei)
        {
            return true;
        }
        
        //MORADA
        public static bool InsereMorada(Morada m)
        {
            if (morada.Contains(m))
            {  
                return false;
            }
            else 
            { 
                morada.Add(m); 
                return true; 
            }
        }

        /// <summary>
        /// Metodo para verificar a existencia de uma morada
        /// </summary>
        /// <param name="em">Variavel que vai receber o valor para verificar se a morada já existe</param>
        /// <returns></returns>
        public static bool ExisteMorada (int em)
        {
            return true;
        }

        //CLIENTE
        /// <summary>
        /// Metodo para Inserir um cliente
        /// </summary>
        /// <param name="c">Variavel que vai receber o valor para ser adicionado</param>
        /// <returns></returns>
        public static bool InsereCliente(Cliente c)
        {
            if (cliente.Contains(c))
            {
                return false;
            }
            else
            {
                cliente.Add(c);
                return true;
            }
        }

        /// <summary>
        /// Metodo para verificar a existencia de um cliente
        /// </summary>
        /// <param name="ec">Variavel que vai receber o valor para verificar se o cliente já existe</param>
        /// <returns></returns>
        public static bool ExisteCliente(int ec)
        {
            return true;
        }

        //PROPRIETARIO
        /// <summary>
        /// Metodo para Inserir um proprietario
        /// </summary>
        /// <param name="c">Variavel que vai receber o valor para ser adicionado</param>
        /// <returns></returns>
        public static bool InsereProprietario(Proprietario p)
        {
            if (proprietario.Contains(p))
            {
                return false;
            }
            else
            {
                proprietario.Add(p);
                return true;
            }
        }

        /// <summary>
        /// Metodo para verificar a existencia de um proprietario
        /// </summary>
        /// <param name="ep">Variavel que vai receber o valor para verificar se o proprietario já existe</param>
        /// <returns></returns>
        public static bool ExisteProprietario (int ep)
        {
            return true;
        }

      

        //IMOVEL
        public static bool GuardaDados(string f)
        {
            try
            {
                Stream s = File.Open(f, FileMode.Create);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, imovel);
                s.Close();
                return true;
            }
            catch
            {
                throw new Exception("Impossivel aceder a ficheiro..");
            }
        }

        public static bool CarregaDados(string f)
        {
            try
            {
                Stream s = File.Open(f, FileMode.Open, FileAccess.Read);
                BinaryFormatter b = new BinaryFormatter();
                imovel = (List<Imovel>)b.Deserialize(s);
                s.Close();
                return true;
            }
            catch (Exception e)
            {
                throw new Exception("Erro...:" + e.Message);
            }
        }
        #endregion
        #endregion

    }
}
