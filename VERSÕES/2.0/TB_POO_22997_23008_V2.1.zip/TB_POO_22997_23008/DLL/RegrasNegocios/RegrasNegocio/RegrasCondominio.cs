﻿using Dados;
using ObjetosNegocios;
using System;


namespace RegrasNegocio
{
    public class RegrasCondominio
    {
        
        /// <summary>
        /// Verifica a existencia de um imovel no condominio a partir do metodo ExisteImovel e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="i">Responsável por procurar a variavel inserida pelo user na LIST Imovel</param>
        /// <returns></returns>
        public static bool InsereImovel(Imovel i)
        {
            if (Condominio.ExisteImovel(i.IdPredial))
            {
                Console.WriteLine("Imovel já existente!");
                return false;
            }
            else
            { 
                Condominio.InsereImovel(i); Console.WriteLine("Imovel inserido com sucesso!"); 
                return true;
            }
        }

        /// <summary>
        /// Verifica a existencia de um imovel no condominio a partir do metodo ExisteImovel e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="m">Responsável por procurar a variavel inserida pelo user na LIST </param>
        /// <returns></returns>
        public static bool InsereMorada(Morada m)
        {
            if (Condominio.ExisteMorada(m.IdMorada))
            {

                Console.WriteLine("Morada já existente!");
                return false;
            }
            else
            {
                Condominio.InsereMorada(m);
                Console.WriteLine("Morada inserida com sucesso!");
                return true;
            }
        }

        /// <summary>
        /// Verifica a existencia de um Cliente no condominio a partir do metodo ExisteCliente e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="c">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static bool InsereCliente(Cliente c)
        {
            if (Condominio.ExisteCliente(c.ContribuinteCliente))
            {
                Console.WriteLine("Cliente já existente!");
                return false;
            }
            else
            {
                Condominio.InsereCliente(c); Console.WriteLine("Cliente inserido com sucesso!");
                return true;
            }
        }

        /// <summary>
        /// Verifica a existencia de um Proprietario no condominio a partir do metodo ExisteProprietario e adiciona ou não, consoante a existencia
        /// </summary>
        /// <param name="p">Responsável por procurar a variavel inserida pelo user na LIST</param>
        /// <returns></returns>
        public static bool InsereProprietario (Proprietario p) 
        {
            if(Condominio.ExisteProprietario(p.ContribuinteProp))
            {
                Console.WriteLine("Proprietário já existente!");
                return false;
            }
            else
            {
                Condominio.InsereProprietario(p); Console.WriteLine("Proprietário inserido com sucesso!");
                return true;
            }
        }
    }
}
