﻿using Interfaces;

namespace ObjetosNegocios
{
    public class Morada : IMorada
    {
        #region ATRIBUTOS

        private int idMorada;
        private string rua;
        private int nPorta;
        private int codPostal;
        private string localidade;


        #endregion

        #region COMPORTAMENTO

        #region CONSTRUTORES
        public Morada()
        {

        }

        #endregion
        #region PROPRIEDADES
        public int IdMorada
        {
            get { return idMorada; }
            set { idMorada = value; }
        }
        public string Rua
        {
            get { return rua; }
            set { rua = value; }
        }

        public int NPorta
        {
            get { return nPorta; }
            set { nPorta = value; }
        }

        public int CodPostal
        {
            get { return codPostal; }
            set { codPostal = value; }
        }

        public string Localidade
        {
            get { return localidade; }
            set { localidade = value; }
        }
        #endregion

        #endregion
    }
}
