﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegrasNegocio;
using ObjetosNegocios; 

namespace Programa_Teste
{
    class Program
    {
        static void Main(string[] args)
        {
            Imovel i = new Imovel();
            i.IdPredial = 0;

            Morada m = new Morada();
            m.IdMorada = 0;

            bool aux = RegrasCondominio.InsereImovel(i);
            bool au = RegrasCondominio.InsereMorada(m);

            Console.WriteLine("ola eu e o meu coleha {0} {1} ", aux, au);
            Console.ReadKey();
        }
    }
}
