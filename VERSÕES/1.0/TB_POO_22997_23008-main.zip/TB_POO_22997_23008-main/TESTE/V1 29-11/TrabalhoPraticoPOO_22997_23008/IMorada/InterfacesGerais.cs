﻿
namespace Interfaces
{
    /// <summary>
    /// Interface Moradas
    /// </summary>
    public interface IMoradas
    {
        int IdMorada {  get; set; }
    }

    /// <summary>
    /// Interface Imoveis
    /// </summary>
    public interface IImoveis
    {
        int IdPredial { get; set; }

    }
}
