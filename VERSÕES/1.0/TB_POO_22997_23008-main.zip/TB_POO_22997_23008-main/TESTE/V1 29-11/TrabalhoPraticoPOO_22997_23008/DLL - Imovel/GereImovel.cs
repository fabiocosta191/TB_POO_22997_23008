﻿using System;
using System.Collections.Generic;
using DLLImovel;

namespace DLLImovel
{
    public class GereImovel
    {
        #region ATRIBUTOS
        private List<Morada> morada;

        #region COMPORTAMENTO
        public GereImovel()
        {

        }
        #endregion

        #region PROPRIEDADES
        #endregion

        #region OUTROS METODOS

        #endregion
        #endregion
    }
}