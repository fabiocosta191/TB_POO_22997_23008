﻿/*
 *  Class Dono
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 01/11/2023
*/

namespace DLLImovel
{
    public class Proprietario
    {
        #region Estado
        private string nomeDono;
        private string iban;
        private int contribuinteDono;
        #endregion
        #region COMPORTAMENTO

        #region CONSTROTORES

        #endregion
        #region PROPRIEDADES

        #endregion
        #endregion
    }
}
