﻿/*
 *  Class Contrato
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 01/11/2023
*/
namespace GestorImovel
{
    internal class Contrato
    {
        #region Estado
        private int nContrato;
        private int nContribuinteCliente;
        private int idPredial;
        #endregion

        #region COMPORTAMENTO

        #region CONSTROTORES

        #endregion
        #region PROPRIEDADES

        #endregion
        #endregion
    }
}
