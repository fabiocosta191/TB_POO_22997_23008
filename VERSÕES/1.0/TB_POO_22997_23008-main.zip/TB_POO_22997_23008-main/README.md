# TB_POO_22997_23008

Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas

Contato: a22997@alunos.ipca.pt || a23008@alunos.ipca.pt

_____________________________________________________________________________________

Docente: Luis Ferreira

Contato: lufer@ipca.pt

_____________________________________________________________________________________

Unidade Curricular (UC): Programação Orientada a Objetos

Curso: Licenciatura em Engenharia de Sistemas Informáticos

Instituto: Escola Superior de Tecnologia do Instituto Politécnico do Cávado e do Ave
_____________________________________________________________________________________

Este projeto é desenvolvido, no ambito da Unidade Curricular (UC) de Programação Orientada a Objetos (POO),  e foca-se na análise de problemas reais simples e a aplicação do Paradigma Orientado a Objetos na implementação de possíveis soluções. Regras do trabalho em anexo "Trabalho_POO_ESI_2023_2024.pdf";
