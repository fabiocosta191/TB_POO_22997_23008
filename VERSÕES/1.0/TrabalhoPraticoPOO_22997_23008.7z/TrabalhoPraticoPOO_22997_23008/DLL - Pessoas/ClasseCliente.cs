﻿/*
 *  Class Cliente
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 01/11/2023
*/
using System;
using DLLInterfaces;

namespace DLLPessoas
{
    public class ClasseCliente : ICliente
    {       
        #region ATRIBUTOS
        private string nomeCliente;
        private int contribuinteCliente;
        private DateTime nascimento; //nascimento = new DateTime(2000, 12, 12);
        #endregion

        #region METODOS

        #region CONSTRUTORES
        public ClasseCliente()
        {

        }

        #endregion
        #region PROPRIEDADES
        public string NomeCliente
        {
            get { return nomeCliente; }

            set { nomeCliente = value; }
        }

        public int ContribuinteCliente
        {
            get { return contribuinteCliente; }

            set { contribuinteCliente = value; }
        }

        #endregion
        #endregion
    }
}
