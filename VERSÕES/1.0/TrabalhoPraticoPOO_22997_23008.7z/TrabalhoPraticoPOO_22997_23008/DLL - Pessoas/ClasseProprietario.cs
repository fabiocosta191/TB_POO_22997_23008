﻿/*
 *  Class Proprietário
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 01/11/2023
*/
using DLLInterfaces;
namespace DLLPessoas
{
    public class ClasseProprietario : IProprietario
    {
        #region ATRIBUTOS
        private string nomeProp;
        private string ibanProp;
        private int contribuinteProp;
        private int telemovelProp;
        private int emailProp;

        #endregion
        #region METODOS

        #region CONSTRUTORES
        public ClasseProprietario()
        {

        }
        #endregion
        #region PROPRIEDADES
        public int ContribuinteProp
        {
            get { return contribuinteProp; }
            set { contribuinteProp = value;}
        }

        public string NomeProp
        {
            get { return nomeProp; }    
            set { nomeProp = value; }
        }
        #endregion
        #endregion
    }
}
