﻿/*Class Cliente
* Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997 @alunos.ipca.pt || a23008@alunos.ipca.pt
 * Data: 16 / 11 / 2023
*/

using DLLInterfaces;

namespace DLL___Pessoas
{
    internal class ClasseOperador : IOperador
    {
        #region ATRIBUTOS

        private string nomeOperador;
        private int nOperador;
        private int telemovelOperador;
        private int emailOperador;
        #endregion
        #region METODOS

        #region CONSTRUTORES
        public ClasseOperador()
        {

        }

        #endregion
        #region PROPRIEDADES
        public int NOperador
        {
            get { return nOperador; }
            set { nOperador = value; }
        }

        public string NomeOperador
        {
            get { return nomeOperador; }
            set { nomeOperador = value;}
        }
        #endregion
        #endregion
    }
}
