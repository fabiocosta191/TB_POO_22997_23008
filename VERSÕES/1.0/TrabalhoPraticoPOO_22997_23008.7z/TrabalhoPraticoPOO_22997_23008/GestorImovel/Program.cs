﻿/*
 * Trabalho Pratico POO - Gestor de rendas/ imoveis
 * 
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Unidade Curricular (UC): Programação Orientada a Objetos
 *	Docente: Luis Ferreira
 *	Contato: lufer@ipca.pt
 *	Curso: Licenciatura em Engenharia de Sistemas Informáticos
 *	Instituto: Escola Superior de Tecnologia do Instituto Politécnico do Cávado e do Ave 
 *	Data: 01/11/2023
*/

using System;
using System.Collections.Generic;
using DLLPessoas;
namespace GestorImovel
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var clientes = new List<ClasseCliente>()
            {
                new ClasseCliente() { NomeCliente = "ola", ContribuinteCliente = 1 }
            };

            foreach (
            {

            }
            
            
    }
}
