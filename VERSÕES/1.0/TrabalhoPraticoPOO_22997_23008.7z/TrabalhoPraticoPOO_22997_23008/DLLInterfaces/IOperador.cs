﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLLInterfaces
{
    public interface IOperador
    {
        int NOperador { get; set; }
        string NomeOperador { get;  set; }

    }
}
