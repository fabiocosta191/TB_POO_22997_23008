﻿/*
 * Interface Pessoas
 * Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 * Contato: a22997 @alunos.ipca.pt || a23008@alunos.ipca.pt
 * Data: 16 / 11 / 2023
*/
namespace DLLInterfaces
{
    /// <summary>
    /// 
    /// </summary> 
    public interface ICliente
    {
        int ContribuinteCliente { get; set; }
        string NomeCliente { get; set; }

    }
}
