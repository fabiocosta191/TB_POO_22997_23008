﻿/*
 *  Classe Imovel
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 01/11/2023
*/

using System;

namespace DLLImovel
{
    class ClasseImovel
    {
        #region ATRIBUTOS
        private string estadoPredial;
        private string categoria;
        private string idPredial;
        private int valorAluguer;
        private int valorPredial;
        #endregion
        #region METODOS
         
        #region CONSTRUTORES
        public ClasseImovel()
        {

        }
        #endregion
        #region PROPRIEDADES

        #endregion
        #endregion
    }
}
