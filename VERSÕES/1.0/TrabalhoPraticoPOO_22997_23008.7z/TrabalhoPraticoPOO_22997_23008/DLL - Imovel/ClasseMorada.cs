﻿/*
 *  Class Morada
 *	Autor: Fábio Rafael Gomes Costa || Luis Pedro Pereira Freitas
 *	Contato: a22997@alunos.ipca.pt ||a23008@alunos.ipca.pt
 *	Data: 01/11/2023
*/
using System;

namespace DLLPessoas
{
    public class ClasseMorada
    {
        #region ATRIBUTOS
        private string rua;
        private string codPostal;
        private string idPredial;
        private string freguesia;
        private int nPorta;
        #endregion

        #region METODOS

        #region CONSTRUTORES
        public ClasseMorada()
        {

        }
        #endregion
        #region PROPRIEDADES

        #endregion
        #endregion

    }
}
